<?php
// move.php
require_once 'includes/session.php';
require_once 'config/database.php';

requireLogin();

$userId = $_SESSION['user_id'];
$input = json_decode(file_get_contents('php://input'), true);
$items = $input['items'] ?? [];
$targetFolder = $input['folder'] ?? 'root';

if (empty($items)) {
    $items = $_POST['items'] ?? [];
    $targetFolder = $_POST['folder'] ?? 'root';
}

if (empty($items)) {
    header("Location: files.php?tab=user&error=Aucun élément sélectionné");
    exit();
}

$database = new Database();
$pdo = $database->getConnection();

// Récupérer les infos du dossier cible
if ($targetFolder === 'root') {
    $targetPath = '';
    $targetId = null;
} else {
    $stmt = $pdo->prepare("SELECT path FROM folders WHERE id = ? AND user_id = ?");
    $stmt->execute([$targetFolder, $userId]);
    $target = $stmt->fetch();
    
    if (!$target) {
        header("Location: files.php?tab=user&error=Dossier cible introuvable");
        exit();
    }
    $targetPath = $target['path'];
    $targetId = $targetFolder;
}

$moved = 0;
$errors = 0;

foreach ($items as $item) {
    if (strpos($item, 'folder_') === 0) {
        // Déplacer un dossier
        $folderId = str_replace('folder_', '', $item);
        
        // Récupérer les infos
        $stmt = $pdo->prepare("SELECT name, path FROM folders WHERE id = ? AND user_id = ?");
        $stmt->execute([$folderId, $userId]);
        $folder = $stmt->fetch();
        
        if ($folder) {
            // Vérifier qu'on ne déplace pas dans un sous-dossier de lui-même
            if ($targetPath && strpos($targetPath, $folder['path']) === 0) {
                $errors++;
                continue;
            }
            
            // Ancien et nouveau chemin
            $oldPhysicalPath = 'uploads/user_' . $userId . '/' . $folder['path'];
            $newPhysicalPath = 'uploads/user_' . $userId . '/' . ($targetPath ? $targetPath . '/' : '') . $folder['name'];
            $newDbPath = ($targetPath ? $targetPath . '/' : '') . $folder['name'];
            
            if (file_exists($oldPhysicalPath)) {
                rename($oldPhysicalPath, $newPhysicalPath);
            }
            
            // Mettre à jour en BDD
            $stmt = $pdo->prepare("UPDATE folders SET parent_id = ?, path = ? WHERE id = ?");
            $stmt->execute([$targetId, $newDbPath, $folderId]);
            $moved++;
        } else {
            $errors++;
        }
        
    } elseif (strpos($item, 'file_') === 0) {
        // Déplacer un fichier
        $fileId = str_replace('file_', '', $item);
        
        // Récupérer les infos
        $stmt = $pdo->prepare("SELECT name, path FROM files WHERE id = ? AND user_id = ?");
        $stmt->execute([$fileId, $userId]);
        $file = $stmt->fetch();
        
        if ($file) {
            // Ancien et nouveau chemin
            $oldPhysicalPath = 'uploads/' . $file['path'];
            $newPhysicalPath = 'uploads/user_' . $userId . '/' . ($targetPath ? $targetPath . '/' : '') . $file['name'];
            
            if (file_exists($oldPhysicalPath)) {
                rename($oldPhysicalPath, $newPhysicalPath);
            }
            
            // Mettre à jour en BDD
            $newDbPath = 'user_' . $userId . '/' . ($targetPath ? $targetPath . '/' : '') . $file['name'];
            $stmt = $pdo->prepare("UPDATE files SET folder_id = ?, path = ? WHERE id = ?");
            $stmt->execute([$targetId, $newDbPath, $fileId]);
            $moved++;
        } else {
            $errors++;
        }
    }
}

// Redirection
if ($errors > 0) {
    $msg = urlencode("$moved élément(s) déplacé(s), $errors erreur(s)");
    header("Location: files.php?tab=user&error=$msg");
} else {
    $msg = urlencode("$moved élément(s) déplacé(s) avec succès");
    header("Location: files.php?tab=user&success=$msg");
}
exit();
?>
<?php
// download.php
require_once 'includes/session.php';
require_once 'config/database.php';

requireLogin();

$userId = $_SESSION['user_id'];
$fileId = $_GET['id'] ?? 0;

$database = new Database();
$pdo = $database->getConnection();

// Récupérer les infos du fichier
$stmt = $pdo->prepare("SELECT name, original_name, path FROM files WHERE id = ? AND user_id = ?");
$stmt->execute([$fileId, $userId]);
$file = $stmt->fetch();

if (!$file) {
    header("Location: files.php?tab=user&error=Fichier introuvable");
    exit();
}

$filePath = 'uploads/' . $file['path'];

if (file_exists($filePath)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit();
} else {
    header("Location: files.php?tab=user&error=Fichier introuvable sur le serveur");
    exit();
}
?>
<?php
// files.php
require_once 'includes/session.php';
require_once 'config/database.php';

requireLogin();

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];
$activeTab = $_GET['tab'] ?? 'system';
$currentFolder = $_GET['folder'] ?? 'root';
$viewMode = $_GET['view'] ?? 'details';

$database = new Database();
$pdo = $database->getConnection();

// Récupérer les fichiers système
$systemFiles = $pdo->query("SELECT * FROM system_files ORDER BY type DESC, name")->fetchAll();

// Récupérer les dossiers utilisateur du niveau courant
if ($currentFolder === 'root') {
    $stmt = $pdo->prepare("SELECT * FROM folders WHERE user_id = ? AND parent_id IS NULL ORDER BY name");
    $stmt->execute([$userId]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM folders WHERE user_id = ? AND parent_id = ? ORDER BY name");
    $stmt->execute([$userId, $currentFolder]);
}
$userFolders = $stmt->fetchAll();

// Récupérer les fichiers utilisateur du dossier courant
if ($currentFolder === 'root') {
    $stmt = $pdo->prepare("SELECT * FROM files WHERE user_id = ? AND folder_id IS NULL ORDER BY created_at DESC");
    $stmt->execute([$userId]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM files WHERE user_id = ? AND folder_id = ? ORDER BY created_at DESC");
    $stmt->execute([$userId, $currentFolder]);
}
$userFiles = $stmt->fetchAll();

// Récupérer TOUS les dossiers utilisateur (pour le sélecteur de déplacement)
$stmtAll = $pdo->prepare("SELECT * FROM folders WHERE user_id = ? ORDER BY name");
$stmtAll->execute([$userId]);
$allUserFolders = $stmtAll->fetchAll();

// Récupérer les infos du dossier courant pour le breadcrumb
$currentFolderData = null;
if ($currentFolder !== 'root') {
    $stmt = $pdo->prepare("SELECT * FROM folders WHERE id = ? AND user_id = ?");
    $stmt->execute([$currentFolder, $userId]);
    $currentFolderData = $stmt->fetch();
}

// Fonctions utilitaires
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 0) . ' Ko';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 0) . ' Ko';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 0) . ' Ko';
    }
    return $bytes . ' o';
}

function formatDate($date) {
    return date('d/m/Y H:i', strtotime($date));
}

function getFileIcon($filename, $type) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $icons = [
        'txt' => '📝', 'pdf' => '📑', 'jpg' => '🖼️', 'jpeg' => '🖼️',
        'png' => '🖼️', 'gif' => '🖼️', 'mp3' => '🎵', 'mp4' => '🎬',
        'mov' => '🎬', 'avi' => '🎬', 'doc' => '📄', 'docx' => '📄',
        'xls' => '📊', 'xlsx' => '📊', 'zip' => '📦', 'rar' => '📦'
    ];
    return $icons[$ext] ?? ($type === 'directory' ? '📁' : '📄');
}

function getFileTypeCategory($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $audio = ['mp3', 'wav', 'ogg', 'flac', 'm4a'];
    $video = ['mp4', 'mov', 'avi', 'mkv', 'webm'];
    $image = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'];
    $text = ['txt', 'md', 'json', 'xml', 'csv', 'log', 'php', 'js', 'css', 'html'];
    
    if (in_array($ext, $audio)) return 'audio';
    if (in_array($ext, $video)) return 'video';
    if (in_array($ext, $image)) return 'image';
    if (in_array($ext, $text)) return 'text';
    return 'file';
}

$totalItems = count($userFolders) + count($userFiles);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes fichiers - Lun'Drive</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="files-page">
    <div class="files-wrapper">
        <!-- Sidebar -->
        <aside class="files-sidebar">
            <div class="sidebar-logo">
                <h1>LUN'DRIVE</h1>
            </div>
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-link">
                    <span class="nav-icon">🏠</span>
                    <span>Tableau de bord</span>
                </a>
                <a href="files.php" class="nav-link active">
                    <span class="nav-icon">📁</span>
                    <span>Mes fichiers</span>
                </a>
            </nav>
            <div class="sidebar-footer">
                <div class="user-info-sidebar">
                    <div class="user-avatar-small"><?= strtoupper(substr($username, 0, 2)) ?></div>
                    <div class="user-details">
                        <div class="user-name-sidebar"><?= htmlspecialchars($username) ?></div>
                        <div class="user-email-sidebar"><?= htmlspecialchars($_SESSION['email']) ?></div>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn-sidebar">LOG OUT</a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="files-main">
            <!-- En-tête avec onglets -->
            <div class="files-header">
                <div class="files-tabs">
                    <a href="?tab=system" class="tab <?= $activeTab === 'system' ? 'active' : '' ?>">Système</a>
                    <a href="?tab=user&folder=root" class="tab <?= $activeTab === 'user' ? 'active' : '' ?>">Utilisateur</a>
                </div>
                <div class="header-actions">
                    <button class="action-icon" title="Paramètres" id="settingsBtn">⚙️</button>
                </div>
            </div>

            <!-- Affichage selon l'onglet -->
            <?php if ($activeTab === 'system'): ?>
                <!-- ========== ONGLET SYSTÈME ========== -->
                <div class="files-container">
                    <div class="files-list">
                        <div class="list-header">
                            <div class="col-checkbox"><input type="checkbox" id="selectAll"></div>
                            <div class="col-name">Nom</div>
                            <div class="col-date">Date</div>
                            <div class="col-type">Type</div>
                            <div class="col-size">Taille</div>
                            <div class="col-actions">Actions</div>
                        </div>
                        <?php foreach ($systemFiles as $file): ?>
                            <div class="file-row" data-id="<?= $file['id'] ?>" data-type="system">
                                <div class="col-checkbox">
                                    <input type="checkbox" class="file-checkbox" value="system_<?= $file['id'] ?>">
                                </div>
                                <div class="col-name">
                                    <span class="file-icon"><?= $file['type'] === 'directory' ? '📁' : getFileIcon($file['name'], 'file') ?></span>
                                    <span class="file-name"><?= htmlspecialchars($file['name']) ?></span>
                                </div>
                                <div class="col-date"><?= formatDate($file['modified_at']) ?></div>
                                <div class="col-type"><?= $file['type'] === 'directory' ? 'Dossier' : 'Fichier' ?></div>
                                <div class="col-size"><?= formatFileSize($file['size']) ?></div>
                                <div class="col-actions">
                                    <?php if ($file['type'] !== 'directory'): ?>
                                        <a href="download_system_file.php?path=<?= urlencode($file['path']) ?>" class="action-download" title="Télécharger">⬇️</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

            <?php else: ?>
                <!-- ========== ONGLET UTILISATEUR ========== -->
                
                <!-- Barre de navigation (breadcrumb) -->
                <div class="breadcrumb">
                    <a href="?tab=user&folder=root" class="breadcrumb-item <?= $currentFolder === 'root' ? 'active' : '' ?>">
                        📁 Racine
                    </a>
                    <?php if ($currentFolder !== 'root' && $currentFolderData): ?>
                        <span class="breadcrumb-separator">/</span>
                        <span class="breadcrumb-item active"><?= htmlspecialchars($currentFolderData['name']) ?></span>
                    <?php endif; ?>
                </div>
                
                <!-- Barre d'actions -->
                <div class="actions-bar">
                    <div class="actions-left">
                        <!-- Formulaire Nouveau Dossier -->
                        <form method="POST" action="create_folder.php" style="display: inline;">
                            <input type="hidden" name="folder" value="<?= $currentFolder ?>">
                            <input type="text" name="name" placeholder="Nom du dossier" class="inline-input" required>
                            <button type="submit" class="action-btn">➕ Nouveau dossier</button>
                        </form>
                        
                        <!-- Formulaire Import -->
                        <form method="POST" action="upload.php" enctype="multipart/form-data" style="display: inline;">
                            <input type="hidden" name="folder" value="<?= $currentFolder ?>">
                            <input type="file" name="files[]" multiple style="display: none;" id="fileInput" onchange="this.form.submit()">
                            <button type="button" class="action-btn" onclick="document.getElementById('fileInput').click()">📥 Importer</button>
                        </form>
                        
                        <!-- Formulaire Suppression -->
                        <form method="POST" action="delete.php" style="display: inline;" id="deleteForm" onsubmit="return prepareDelete()">
                            <input type="hidden" name="items" id="deleteItems" value="">
                            <input type="hidden" name="folder" value="<?= $currentFolder ?>">
                            <button type="submit" class="action-btn">🗑️ Supprimer</button>
                        </form>
                        
                        <!-- Formulaire Renommer -->
                        <form method="POST" action="rename.php" style="display: inline;" id="renameForm">
                            <input type="hidden" name="id" id="renameId" value="">
                            <input type="hidden" name="folder" value="<?= $currentFolder ?>">
                            <input type="text" name="name" id="renameName" placeholder="Nouveau nom" class="inline-input" style="display: none;">
                            <button type="button" class="action-btn" onclick="prepareRename()">✏️ Renommer</button>
                        </form>
                        
                        <!-- Formulaire Déplacer -->
                        <form method="POST" action="move.php" style="display: inline;" id="moveForm">
                            <input type="hidden" name="items" id="moveItems" value="">
                            <input type="hidden" name="folder" value="<?= $currentFolder ?>">
                            <select name="target_folder" id="moveFolderSelect" style="display: none;">
                                <option value="root">Racine</option>
                                <?php foreach ($allUserFolders as $folder): ?>
                                    <?php if ($folder['id'] != $currentFolder): ?>
                                        <option value="<?= $folder['id'] ?>">📁 <?= htmlspecialchars($folder['name']) ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                            <button type="button" class="action-btn" onclick="prepareMove()">📂 Déplacer vers</button>
                        </form>
                    </div>
                    
                    <div class="actions-right">
                        <div class="view-mode">
                            <button class="view-btn <?= $viewMode === 'details' ? 'active' : '' ?>" data-view="details" title="Détails">📋</button>
                            <button class="view-btn <?= $viewMode === 'list' ? 'active' : '' ?>" data-view="list" title="Liste">📝</button>
                            <button class="view-btn <?= $viewMode === 'icons' ? 'active' : '' ?>" data-view="icons" title="Icônes">🖼️</button>
                        </div>
                    </div>
                </div>
                
                <!-- Liste des fichiers -->
                <div class="files-container">
                    <div class="files-list details-view">
                        <div class="list-header">
                            <div class="col-checkbox"><input type="checkbox" id="selectAllUser" onclick="toggleAll(this)"></div>
                            <div class="col-name">Nom</div>
                            <div class="col-date">Date</div>
                            <div class="col-type">Type</div>
                            <div class="col-size">Taille</div>
                            <div class="col-actions">Actions</div>
                        </div>
                        
                        <?php if (empty($userFolders) && empty($userFiles)): ?>
                            <div class="empty-state">
                                <div class="empty-icon">📂</div>
                                <p class="empty-title">Ce dossier est encore vide</p>
                                <p class="empty-subtitle">Commencez par importer des fichiers ou créer un dossier !</p>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Dossiers -->
                        <?php foreach ($userFolders as $folder): ?>
                            <div class="file-row folder-row" data-id="<?= $folder['id'] ?>" data-type="folder" ondblclick="window.location.href='?tab=user&folder=<?= $folder['id'] ?>'">
                                <div class="col-checkbox">
                                    <input type="checkbox" class="file-checkbox" value="folder_<?= $folder['id'] ?>">
                                </div>
                                <div class="col-name">
                                    <span class="file-icon">📁</span>
                                    <a href="?tab=user&folder=<?= $folder['id'] ?>" class="folder-link"><?= htmlspecialchars($folder['name']) ?></a>
                                </div>
                                <div class="col-date"><?= formatDate($folder['created_at']) ?></div>
                                <div class="col-type">Dossier</div>
                                <div class="col-size">-</div>
                                <div class="col-actions">
                                    <button class="action-delete" onclick="deleteSingleItem('folder_<?= $folder['id'] ?>')" title="Supprimer">🗑️</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <!-- Fichiers -->
                        <?php foreach ($userFiles as $file): 
                            $fileCategory = getFileTypeCategory($file['original_name']);
                        ?>
                            <div class="file-row" data-id="<?= $file['id'] ?>" data-type="file" ondblclick="openFile(<?= $file['id'] ?>, '<?= $fileCategory ?>')">
                                <div class="col-checkbox">
                                    <input type="checkbox" class="file-checkbox" value="file_<?= $file['id'] ?>">
                                </div>
                                <div class="col-name">
                                    <span class="file-icon"><?= getFileIcon($file['original_name'], 'file') ?></span>
                                    <span class="file-name"><?= htmlspecialchars($file['original_name']) ?></span>
                                </div>
                                <div class="col-date"><?= formatDate($file['created_at']) ?></div>
                                <div class="col-type"><?= htmlspecialchars($file['type']) ?></div>
                                <div class="col-size"><?= formatFileSize($file['size']) ?></div>
                                <div class="col-actions">
                                    <?php if ($fileCategory === 'text' || $fileCategory === 'image' || $fileCategory === 'audio' || $fileCategory === 'video'): ?>
                                        <a href="view_file.php?id=<?= $file['id'] ?>" class="action-view" target="_blank" title="Voir">👁️</a>
                                    <?php endif; ?>
                                    <a href="download.php?id=<?= $file['id'] ?>" class="action-download" title="Télécharger">⬇️</a>
                                    <button class="action-delete" onclick="deleteSingleItem('file_<?= $file['id'] ?>')" title="Supprimer">🗑️</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Formulaire caché pour suppression individuelle -->
                <form method="POST" id="singleDeleteForm" action="delete.php" style="display: none;">
                    <input type="hidden" name="items" id="singleDeleteItems">
                    <input type="hidden" name="folder" value="<?= $currentFolder ?>">
                </form>
                
                <!-- Barre du bas avec compteurs -->
                <div class="files-footer">
                    <div class="footer-left">
                        <span class="total-count"><?= $totalItems ?> élément(s)</span>
                        <span class="selected-count" id="selectedCount">0 élément sélectionné</span>
                    </div>
                    <div class="footer-right">
                        <div class="view-mode-footer">
                            <button class="view-mode-btn <?= $viewMode === 'details' ? 'active' : '' ?>" data-view="details">📋 Détails</button>
                            <button class="view-mode-btn <?= $viewMode === 'list' ? 'active' : '' ?>" data-view="list">📝 Liste</button>
                            <button class="view-mode-btn <?= $viewMode === 'icons' ? 'active' : '' ?>" data-view="icons">🖼️ Icônes</button>
                        </div>
                    </div>
                </div>
                
                <script>
                // Variables
                let currentFolder = '<?= $currentFolder ?>';

                // Sélection multiple
                function toggleAll(source) {
                    const checkboxes = document.querySelectorAll('.file-checkbox');
                    checkboxes.forEach(cb => cb.checked = source.checked);
                    updateSelectedCount();
                }

                function updateSelectedCount() {
                    const selected = document.querySelectorAll('.file-checkbox:checked');
                    const count = selected.length;
                    const selectedCountSpan = document.getElementById('selectedCount');
                    if (selectedCountSpan) {
                        selectedCountSpan.textContent = `${count} élément${count > 1 ? 's' : ''} sélectionné${count > 1 ? 's' : ''}`;
                    }
                }

                function getSelectedItems() {
                    const selected = document.querySelectorAll('.file-checkbox:checked');
                    return Array.from(selected).map(cb => cb.value);
                }

                // Suppression groupée
                function prepareDelete() {
                    const items = getSelectedItems();
                    if (items.length === 0) {
                        alert('Aucun élément sélectionné');
                        return false;
                    }
                    document.getElementById('deleteItems').value = items.join(',');
                    return confirm(`Supprimer ${items.length} élément(s) ?`);
                }

                // Suppression individuelle
                function deleteSingleItem(itemId) {
                    if (confirm('Supprimer cet élément ?')) {
                        const form = document.getElementById('singleDeleteForm');
                        document.getElementById('singleDeleteItems').value = itemId;
                        form.submit();
                    }
                }

                // Renommer
                function prepareRename() {
                    const items = getSelectedItems();
                    if (items.length !== 1) {
                        alert('Veuillez sélectionner un seul élément à renommer');
                        return;
                    }
                    
                    const newName = prompt('Entrez le nouveau nom :');
                    if (newName && newName.trim()) {
                        const form = document.getElementById('renameForm');
                        document.getElementById('renameId').value = items[0];
                        document.getElementById('renameName').value = newName;
                        form.submit();
                    }
                }

                // Déplacer
                let moveConfirmBtn = null;
                function prepareMove() {
                    const items = getSelectedItems();
                    if (items.length === 0) {
                        alert('Aucun élément sélectionné');
                        return;
                    }
                    
                    const select = document.getElementById('moveFolderSelect');
                    select.style.display = 'inline-block';
                    select.style.marginRight = '5px';
                    select.style.padding = '0.5rem';
                    select.style.borderRadius = '6px';
                    select.style.backgroundColor = 'rgba(255,255,255,0.1)';
                    select.style.color = 'white';
                    select.style.border = '1px solid rgba(255,255,255,0.2)';
                    select.focus();
                    
                    if (!moveConfirmBtn) {
                        moveConfirmBtn = document.createElement('button');
                        moveConfirmBtn.id = 'moveConfirmBtn';
                        moveConfirmBtn.textContent = 'Confirmer';
                        moveConfirmBtn.type = 'button';
                        moveConfirmBtn.className = 'action-btn';
                        moveConfirmBtn.style.marginLeft = '5px';
                        moveConfirmBtn.onclick = function() {
                            document.getElementById('moveItems').value = items.join(',');
                            document.getElementById('moveForm').submit();
                        };
                        select.parentNode.insertBefore(moveConfirmBtn, select.nextSibling);
                    } else {
                        moveConfirmBtn.style.display = 'inline-block';
                    }
                }

                // Ouvrir un fichier par double-clic
                function openFile(fileId, category) {
                    if (category === 'text' || category === 'image' || category === 'audio' || category === 'video') {
                        window.open('view_file.php?id=' + fileId, '_blank');
                    } else {
                        if (confirm('Ce type de fichier ne peut pas être visualisé directement.\nVoulez-vous le télécharger ?')) {
                            window.location.href = 'download.php?id=' + fileId;
                        }
                    }
                }

                // Mode d'affichage
                document.querySelectorAll('.view-mode-btn, .view-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const view = this.dataset.view;
                        if (view) {
                            window.location.href = '?tab=user&folder=' + currentFolder + '&view=' + view;
                        }
                    });
                });

                // Initialisation
                document.querySelectorAll('.file-checkbox').forEach(cb => {
                    cb.addEventListener('change', updateSelectedCount);
                });
                updateSelectedCount();

                // Effet de survol
                document.querySelectorAll('.file-row').forEach(row => {
                    row.style.cursor = 'pointer';
                    row.addEventListener('mouseenter', function() {
                        this.style.backgroundColor = 'rgba(255,255,255,0.08)';
                    });
                    row.addEventListener('mouseleave', function() {
                        if (!this.classList.contains('selected')) {
                            this.style.backgroundColor = '';
                        }
                    });
                });
                </script>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>